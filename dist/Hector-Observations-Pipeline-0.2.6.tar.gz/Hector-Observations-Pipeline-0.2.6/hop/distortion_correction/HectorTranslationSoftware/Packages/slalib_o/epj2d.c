/*
** Copyright (C) 2009 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
double slaEpj2d(double qfoo){return 51544.5+(qfoo-2000.0)*
365.25;}
