/*
** Copyright (C) 2009 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
double slaEpb2d(double qfoo){return 15019.81352+(qfoo-1900.0
)*365.242198781;}
