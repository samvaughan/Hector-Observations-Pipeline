/*
** Copyright (C) 2009 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
void slaI2opat(double qfoo,IOpars*qbar){qbar->eral=slaEra(
0.0,qfoo)+qbar->along;}
