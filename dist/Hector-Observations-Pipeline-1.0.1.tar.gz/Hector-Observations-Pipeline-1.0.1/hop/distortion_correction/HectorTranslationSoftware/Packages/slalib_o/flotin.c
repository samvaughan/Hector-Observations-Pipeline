/*
** Copyright (C) 2009 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
void slaFlotin(const char*qfoo,int*qbar,float*qbaz,int*Q0){
double qfobar;slaDfltin(qfoo,qbar,&qfobar,Q0);if(*Q0<=0)*
qbaz=(float)qfobar;}
