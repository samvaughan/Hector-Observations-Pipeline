# Hector optical model SDS files produced by fitting of the offsets produced
#   by Madusha's merging of data from a number of runs.  Updated results as of 22-Apr-2022
#
#  Iteration 2 not used (noisey)
#  Negated offsets
#  Cleared mean offsets
#  Fitted rotation, scale and centre of distortion
#
# Resultant fit give an RMS of 1.2 arc-seconds
#
#
# Tony Farrell, AAO MQ, 22-Apr-2022.

