/*
** Copyright (C) 2009 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
void slaAoppat(double qfoo,double qbar[14]){qbar[13]=slaGmst
(qfoo)+qbar[12];}
