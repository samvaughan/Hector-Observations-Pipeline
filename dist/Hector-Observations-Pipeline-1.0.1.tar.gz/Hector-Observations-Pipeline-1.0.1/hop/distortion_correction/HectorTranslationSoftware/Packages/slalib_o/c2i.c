/*
** Copyright (C) 2009 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
void slaC2i(double qfoo,double qbar,double qbaz,double Q0,
double qfobar,double q1,double q2,double qfoobar,double Q3,
double*q4,double*qfOBAz){CIpars qfoobaz;double QQUUX;
slaC2ipa(q2,qfoobar,Q3,&qfoobaz,&QQUUX);slaC2iqk(qfoo,qbar,
qbaz,Q0,qfobar,q1,&qfoobaz,q4,qfOBAz);}
