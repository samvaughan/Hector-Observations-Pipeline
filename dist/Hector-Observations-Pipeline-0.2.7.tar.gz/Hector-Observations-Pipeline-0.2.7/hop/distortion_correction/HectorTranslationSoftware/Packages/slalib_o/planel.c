/*
** Copyright (C) 2009 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
void slaPlanel(double qfoo,int qbar,double qbaz,double Q0,
double qfobar,double q1,double q2,double qfoobar,double Q3,
double q4,double qfOBAz[6],int*qfoobaz){double QQUUX[13];int
 Q5;slaEl2ue(qfoo,qbar,qbaz,Q0,qfobar,q1,q2,qfoobar,Q3,q4,
QQUUX,&Q5);if(!Q5){slaUe2pv(qfoo,QQUUX,qfOBAz,&Q5);if(Q5)Q5=
-5;}*qfoobaz=Q5;}
