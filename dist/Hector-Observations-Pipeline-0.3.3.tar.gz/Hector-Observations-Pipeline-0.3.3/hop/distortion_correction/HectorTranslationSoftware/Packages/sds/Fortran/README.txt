Routines in this directory provide a Fortran 95 interface to the ARG (argument
library) routines.

Currently (May 2011) they are only used by 2dfdr. 2dfdr provides its own
Makefile and there is nothing in this module to build these routines.

The interface does not include all ARG routines, only those used by 2dfdr.
