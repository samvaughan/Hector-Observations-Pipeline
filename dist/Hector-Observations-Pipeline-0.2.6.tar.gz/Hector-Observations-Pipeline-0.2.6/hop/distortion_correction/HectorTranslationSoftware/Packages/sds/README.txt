# "@(#) $Id: ACMM:sds/README.txt,v 3.94 09-Dec-2020 17:15:24+11 ks $"

The DRAMA Self Defining data System (Sds).  Can also be used
indpendent of DRAMA - see the Standalone directory.

This software has made use of the ESO cmm system (known internally
at AAO as "acmm").  

This module is a DRAMA module - it must have a dmakefile and not
a Makefile.  This will be checked when you archive the module.


This module,  sds, was created from an old SCCS archive.
Version 3.0 is a snapshot taken when it was put into 
ACMM on Fri Jan 17 12:21:29 2003
