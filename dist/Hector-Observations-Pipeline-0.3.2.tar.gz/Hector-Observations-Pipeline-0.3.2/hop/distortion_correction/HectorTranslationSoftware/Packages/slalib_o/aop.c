/*
** Copyright (C) 2009 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
void slaAop(double qfoo,double qbar,double qbaz,double Q0,
double qfobar,double q1,double hm,double q2,double qfoobar,
double tk,double Q3,double rh,double q4,double tlr,double*
qfOBAz,double*qfoobaz,double*QQUUX,double*Q5,double*QFRED){
double qdog[14];slaAoppa(qbaz,Q0,qfobar,q1,hm,q2,qfoobar,tk,
Q3,rh,q4,tlr,qdog);slaAopqk(qfoo,qbar,qdog,qfOBAz,qfoobaz,
QQUUX,Q5,QFRED);}
