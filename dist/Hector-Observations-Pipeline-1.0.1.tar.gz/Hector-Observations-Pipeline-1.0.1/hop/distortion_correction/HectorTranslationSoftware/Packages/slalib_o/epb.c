/*
** Copyright (C) 2009 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
double slaEpb(double qfoo){return 1900.0+(qfoo-15019.81352)/
365.242198781;}
